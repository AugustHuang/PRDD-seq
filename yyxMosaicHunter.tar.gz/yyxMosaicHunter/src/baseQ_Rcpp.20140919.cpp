
#include <Rcpp.h>

using namespace Rcpp;


// [[Rcpp::export]]
LogicalVector yyx_is_within_range__c(NumericVector vec, NumericVector range){
	long n = vec.size();
	LogicalVector out(n);
	
	double range_min = min(range);
	double range_max = max(range);
	
	for(long i = 0; i < n; ++i) {
		out[i] = vec[i] >= range_min && vec[i] <= range_max;
	}
	return out;
}
/*** R
#yyx_is_within_range__c(rep(1:5,5), c(2.5,2,3,4.5))
stopifnot(all( yyx_is_within_range__c(rep(1:5,5), c(2.5,2,3,4.5)) == yyx_is_within_range(rep(1:5,5), c(2.5,2,3,4.5)) ))

#microbenchmark(
#	yyx_is_within_range(rep(1:5,5), c(2.5,2,3,4.5)),
#	yyx_is_within_range__c(rep(1:5,5), c(2.5,2,3,4.5))
#)
*/


// [[Rcpp::export]]
double yyx_log_add_exp__c(double a, double b){
	if(a >= b){
		return a + log(1 + exp(b - a));
	}else{
		return b + log(1 + exp(a - b));
	}
}
/*** R
yyx_log_add_exp__c(-1, -2)
stopifnot(all( yyx_log_add_exp__c(-1, -2) == yyx_log_sum_exp(c(-1, -2)) ))

#microbenchmark(
#	yyx_log_add_exp__c(-1, -2),
#	yyx_log_sum_exp(c(-1, -2))
#)
*/


// [[Rcpp::export]]
double yyx_log_sum_exp__c(NumericVector vec){
	long n = vec.size();
	double vec_max = max(vec);
	
	if(vec_max == INFINITY){
		return vec_max;
	}
	
	double temp = 0.0;
	for(long i = 0; i < n; ++i) {
		temp += exp(vec[i] - vec_max);
	}
	return vec_max + log(temp);
}
/*** R
#yyx_log_sum_exp__c(c(-(1:5), -(10:1)))
stopifnot(all( yyx_log_sum_exp__c(c(-(1:5), -(10:1))) - yyx_log_sum_exp(c(-(1:5), -(10:1))) < .Machine$double.eps ))

#yyx_log_sum_exp__c(c(Inf, 0, 1))
stopifnot(all( yyx_log_sum_exp__c(c(Inf, 0, 1)) == yyx_log_sum_exp(c(Inf, 0, 1)) ))

#microbenchmark(
#	yyx_log_sum_exp(c(-(1:5), -(10:1))),
#	yyx_log_sum_exp__c(c(-(1:5), -(10:1))),
#	times = 1000L
#)
*/


double log_one_minus_exp_P__c(double log_prob){
	return log(1 - exp(log_prob));
}


// [[Rcpp::export]]
NumericVector yyx_log_P_o_given_r_q__c(NumericVector ref_baseQ_vec, NumericVector alt_baseQ_vec){
	long ref_count = ref_baseQ_vec.size();
	long alt_count = alt_baseQ_vec.size();
	long depth = ref_count + alt_count;
	
	double ln_10 = log(10);
	
	NumericVector ref_log_error_rate_vec = ln_10 * -ref_baseQ_vec/10;
	NumericVector alt_log_error_rate_vec = ln_10 * -alt_baseQ_vec/10;
	
	NumericVector ans(depth+1);
	// ans idx=0:depth
	// P(o|r,q) as function of r(real_alt_count)=0:depth
	
	double this_ref_alt_log_prob[2];
	ans[0] = 0;
	long i = 0;
	long j, k;
	for(k = 0; k < ref_count; ++k){
		++i;
		
		this_ref_alt_log_prob[1] = ref_log_error_rate_vec[k];
		this_ref_alt_log_prob[0] = log_one_minus_exp_P__c(ref_log_error_rate_vec[k]);
		
		ans[i] = ans[i-1] + this_ref_alt_log_prob[1];
		
		for(j = i - 1; j >= 1; --j){
			ans[j] = yyx_log_add_exp__c(ans[j] + this_ref_alt_log_prob[0], ans[j-1] + this_ref_alt_log_prob[1]);
		}
		
		ans[0] = ans[0] + this_ref_alt_log_prob[0];
	}
	
	for(k = 0; k < alt_count; ++k){
		++i;
		
		this_ref_alt_log_prob[0] = alt_log_error_rate_vec[k];
		this_ref_alt_log_prob[1] = log_one_minus_exp_P__c(alt_log_error_rate_vec[k]);
		
		ans[i] = ans[i-1] + this_ref_alt_log_prob[1];
		
		for(j = i - 1; j >= 1; --j){
			ans[j] = yyx_log_add_exp__c(ans[j] + this_ref_alt_log_prob[0], ans[j-1] + this_ref_alt_log_prob[1]);
		}
		
		ans[0] = ans[0] + this_ref_alt_log_prob[0];
	}
	
	return ans;
}
/*** R
#yyx_log_P_o_given_r_q(c(10,20,30,40,50,+Inf), c(20,30,40))
#yyx_log_P_o_given_r_q__c(c(10,20,30,40,50,+Inf), c(20,30,40))
stopifnot(all( yyxNA2FALSE(yyx_log_P_o_given_r_q(c(10,20,30,40,50,+Inf), c(20,30,40)) - yyx_log_P_o_given_r_q__c(c(10,20,30,40,50,+Inf), c(20,30,40))) < .Machine$double.eps^0.9 ))

#microbenchmark(
#	yyx_log_P_o_given_r_q(c(10,20,30,40,50,+Inf), c(20,30,40)),
#	yyx_log_P_o_given_r_q__c(c(10,20,30,40,50,+Inf), c(20,30,40)),
#	times = 100L
#)
#
#microbenchmark(
#	yyx_log_P_o_given_r_q(rep(+Inf, 80), rep(+Inf,20)),
#	yyx_log_P_o_given_r_q__c(rep(+Inf, 80), rep(+Inf,20)),
#	times = 100L
#)
#
#microbenchmark(
#	yyx_log_P_o_given_r_q(rep(20, 80), rep(30,20)),
#	yyx_log_P_o_given_r_q__c(rep(20, 80), rep(30,20)),
#	times = 100L
#)
#
#microbenchmark(
#	yyx_log_P_o_given_r_q(rep(20, 800), rep(30,200)),
#	yyx_log_P_o_given_r_q__c(rep(20, 800), rep(30,200)),
#	times = 10L
#)

stopifnot(all( yyx_log_P_o_given_r_q(rep(20, 800), rep(30,200)) - yyx_log_P_o_given_r_q__c(rep(20, 800), rep(30,200)) < .Machine$double.eps^0.7 ))
*/


// [[Rcpp::export]]
NumericVector yyx_log_P_r_given_theta_depth__c(double theta, long depth){
	
	NumericVector ans(depth + 1);
	if(theta==0){
		std::fill(ans.begin(), ans.end(), -INFINITY);
		ans[0] = 0;
	}else if(theta==1){
		std::fill(ans.begin(), ans.end(), -INFINITY);
		ans[depth] = 0;
	}else{
		double log_theta = log(theta);
		double log_1_theta = log(1 - theta);
		for(long i = 0; i <= depth; ++i){
			ans[i] = i * log_theta + (depth - i) * log_1_theta;
		}
	}
	
	return ans;
}
/*** R
#yyx_log_P_r_given_theta_depth__c(0, 100)
#yyx_log_P_r_given_theta_depth__c(1, 100)
#yyx_log_P_r_given_theta_depth__c(0.5, 100)
#yyx_log_P_r_given_theta_depth__c(0.1, 100)
stopifnot(all( yyx_log_P_r_given_theta_depth__c(0, 100) - yyx_log_P_r_given_theta_depth(0, 100) < .Machine$double.eps^0.9 ))
stopifnot(all( yyx_log_P_r_given_theta_depth__c(1, 100) - yyx_log_P_r_given_theta_depth(1, 100) < .Machine$double.eps^0.9 ))
stopifnot(all( yyx_log_P_r_given_theta_depth__c(0.5, 100) - yyx_log_P_r_given_theta_depth(0.5, 100) < .Machine$double.eps^0.9 ))
stopifnot(all( yyx_log_P_r_given_theta_depth__c(0.1, 100) - yyx_log_P_r_given_theta_depth(0.1, 100) < .Machine$double.eps^0.8 ))

#microbenchmark(
#	yyx_log_P_r_given_theta_depth__c(0.1, 100),
#	yyx_log_P_r_given_theta_depth(0.1, 100),
#	times = 100L
#)
*/


// [[Rcpp::export]]
double yyx_log_P_o_given_theta_q__c(double theta, NumericVector log_P_o_given_r_q_vec){
	long depth = log_P_o_given_r_q_vec.size() - 1;
	
	NumericVector log_P_r_given_theta_depth_vec = yyx_log_P_r_given_theta_depth__c(theta, depth);
	
	return yyx_log_sum_exp__c( log_P_o_given_r_q_vec + log_P_r_given_theta_depth_vec );
}
/*** R
log_P_o_given_r_q_vec <- yyx_log_P_o_given_r_q__c(rep(20, 80), rep(30,20))

stopifnot(all(
yyx_log_P_o_given_theta_q(0.5, log_P_o_given_r_q_vec=log_P_o_given_r_q_vec)
-
yyx_log_P_o_given_theta_q__c(0.5, log_P_o_given_r_q_vec)
< .Machine$double.eps^0.9 ))

#microbenchmark(
#	yyx_log_P_o_given_theta_q(0.5, log_P_o_given_r_q_vec=log_P_o_given_r_q_vec),
#	yyx_log_P_o_given_theta_q__c(0.5, log_P_o_given_r_q_vec),
#	times = 100L
#)
*/


// [[Rcpp::export]]
NumericVector yyx_loglikelihood_theta_vec__c(NumericVector ref_baseQ_vec, NumericVector alt_baseQ_vec, NumericVector theta_vec){
	NumericVector log_P_o_given_r_q_vec = yyx_log_P_o_given_r_q__c(ref_baseQ_vec, alt_baseQ_vec);
	
//	NumericVector theta_vec(knots);
//	for(long i = 0; i < knots; ++i){
//		theta_vec[i] = double(i) / knots;
//	}
	long knots = theta_vec.size();
	
	NumericVector loglikelihood_vec(knots);
	for(long i = 0; i < knots; ++i){
		loglikelihood_vec[i] = yyx_log_P_o_given_theta_q__c(theta_vec[i], log_P_o_given_r_q_vec);
	}
	
	return loglikelihood_vec;
}
/*
yyx_loglikelihood_theta_splinefun__call_c <- function(ref_baseQ_vec, alt_baseQ_vec, knots=1001, ...){
	theta_vec <- seq(0,1, length.out=knots)
	loglikelihood_vec <- yyx_loglikelihood_theta_vec__c(ref_baseQ_vec, alt_baseQ_vec, theta_vec)
	stopifnot(length(theta_vec)==length(loglikelihood_vec))
	
	simple_outlier_check_list <- yyx_loglik_simple_outlier_idx(loglikelihood_vec)
	theta_vec_normal<- theta_vec[simple_outlier_check_list$normal_idx]
	loglikelihood_vec_normal <- loglikelihood_vec[simple_outlier_check_list$normal_idx]
	stopifnot(length(theta_vec_normal)==length(loglikelihood_vec_normal))
	
	yyx_restrict_x_interval_function(splinefun(theta_vec_normal, loglikelihood_vec_normal, ...), c(0,1), -Inf)
}
*/

