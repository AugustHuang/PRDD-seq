
# R version 3.1.0 (2014-04-10) -- "Spring Dance", in Windows

##### define functions

### general functions

#' Is each element within the specified range?
#'
#' \code{yyx_is_within_range} returns a bool vector indicating
#' whether each element of input vector is within the specified range
#'
#' @param vec A numeric vector.
#' @param range A vector specify the wanted range.
#' @return A bool vector (can be used as index vector),
#' indicating whether vec[index] is within range.
#'
#' @seealso \code{yyx_is_within_range__c} for Rcpp version
#' @family general functions
#'
#' @examples
#' yyx_is_within_range(1:5, c(2,4.5))
#' #  FALSE  TRUE  TRUE  TRUE FALSE
#'
#' yyx_is_within_range(c(1980,1985,1990,1995), 1982:1992)
#' #  FALSE  TRUE  TRUE FALSE
#'
#' yyx_is_within_range__c(1:5, c(2,4.5))
#' #  FALSE  TRUE  TRUE  TRUE FALSE
#'
yyx_is_within_range <- function(vec, range){
	bool_vec <- ( vec >= min(range) );
	bool_vec <- bool_vec & ( vec <= max(range) );
	bool_vec;
}

#' Convert NA to FALSE
#'
#' \code{yyx_NA2FALSE} just converts NA in input vector to FALSE
#'
#' @param vec A bool (or other type) vector.
#' @return A bool (or other type) vector, the same length as input \code{vec}.
#' NAs in vec will be replaced by FALSE.
#'
#' @seealso \code{\link{yyx_convert_NA}} and \code{\link{yyx_convert_NA_vec}}
#' @family general functions
#'
#' @examples
#' yyx_NA2FALSE(c(TRUE,TRUE,FALSE,NA,TRUE,FALSE,FALSE,TRUE,NA))
#' #  TRUE  TRUE FALSE FALSE  TRUE FALSE FALSE  TRUE FALSE
#'
#' yyx_NA2FALSE(c(1:5,NA,6:10))
#' #  1  2  3  4  5  0  6  7  8  9 10
#'
yyx_NA2FALSE <- function(vec){
	vec[is.na(vec)] <- FALSE
	vec
}

#' Convert NA to default value
#'
#' \code{yyx_convert_NA} just converts NA in input vector to a specified default value
#'
#' @param vec A vector.
#' @param default The specified default value to replace NA.
#' @return A vector, the same length as input \code{vec}.
#' NAs in vec will be replaced by the specified default value.
#'
#' @seealso \code{\link{yyx_NA2FALSE}} and \code{\link{yyx_convert_NA_vec}}
#' @family general functions
#'
#' @examples
#' yyx_convert_NA(c(TRUE,TRUE,FALSE,NA,TRUE,FALSE,FALSE,TRUE,NA))
#' #  TRUE  TRUE FALSE FALSE  TRUE FALSE FALSE  TRUE FALSE
#'
#' yyx_convert_NA(c(1:5,NA,6:10))
#' #  1  2  3  4  5  0  6  7  8  9 10
#'
#' yyx_convert_NA(c(1:5,NA,6:10), -1)
#' #  1  2  3  4  5  -1  6  7  8  9 10
#'
yyx_convert_NA <- function(vec, default=FALSE){
	vec[is.na(vec)] <- default
	vec
}

#' Convert NA to default values in another vector
#'
#' \code{yyx_convert_NA_vec} just converts NA in input vector to the value in another vector
#'
#' @param vec A vector.
#' @param default_vec The specified vector, which should be length=1 or the same length of \code{vec}, so that NAs would be converted to the value in the same position in this vector.
#' @return A vector, the same length as input \code{vec}.
#' NAs in vec will be replaced by the value in the same position in \code{default_vec}.
#'
#' @seealso \code{\link{yyx_NA2FALSE}} and \code{\link{yyx_convert_NA}}
#' @family general functions
#'
#' @examples
#' yyx_convert_NA_vec(c(TRUE,TRUE,FALSE,NA,TRUE,FALSE,FALSE,TRUE,NA), FALSE)
#' #  TRUE  TRUE FALSE FALSE  TRUE FALSE FALSE  TRUE FALSE
#'
#' yyx_convert_NA_vec(c(TRUE,TRUE,FALSE,NA,TRUE,FALSE,FALSE,TRUE,NA), 1:9)
#' #  1 1 0 4 1 0 0 1 9
#'
yyx_convert_NA_vec <- function(vec, default_vec=FALSE){
	stopifnot(length(vec)==length(default_vec) && length(default_vec)!=1)
	default_vec <- rep(default_vec, length.out=length(vec))
	vec[is.na(vec)] <- default_vec[is.na(vec)]
	vec
}

### math functions

#' Compute log_sum_exp (ie. log(sum(exp(vec))) )
#'
#' \code{yyx_log_sum_exp} computes log(sum(exp(vec)))
#'
#' This function is used to compute sum of probability in log-space (Note: not log10)
#'
#' @param vec A numeric vector, usually contains probabilities in log-space.
#' @return A value = log(sum(exp(vec))).
#'
#' @seealso \code{yyx_log_add_exp__c}, \code{yyx_log_sum_exp__c} for Rcpp version
#' @seealso \code{\link{yyx_log10_sum_exp10}}
#' @family math functions
#'
#' @examples
#' yyx_log_sum_exp(-(1:5))
#' # -0.5480856
#'
#' yyx_log_sum_exp(rep(log(0.1),10))
#' # 4.440892e-16
#'
#' yyx_log_sum_exp__c(rep(log(0.1),10))
#' # 4.440892e-16
#'
yyx_log_sum_exp <- function(vec){
	vec_max <- max(vec)
	if(is.finite(vec_max)){
		log(sum(exp(vec - vec_max))) + vec_max
	}else{
		vec_max
	}
}

#' Compute log10_sum_exp10 (ie. log10(sum(10^(vec))) )
#'
#' \code{yyx_log10_sum_exp10} computes log(sum(exp(vec)))
#'
#' This function is used to compute sum of probability in log10-space
#'
#' @param vec A numeric vector, usually contains probabilities in log10-space.
#' @return A value = log10(sum(10^(vec))).
#'
#' @seealso \code{\link{yyx_log_sum_exp}}
#' @family math functions
#'
#' @examples
#' yyx_log10_sum_exp10(-(1:5))
#' # -0.9542469
#'
#' yyx_log10_sum_exp10(rep(-1,10))
#' # 0
#'
yyx_log10_sum_exp10 <- function(vec){
	vec_max <- max(vec)
	if(is.finite(vec_max)){
		log10(sum(10^(vec - vec_max))) + vec_max
	}else{
		vec_max
	}
}
### mosaic model related functions

#' Compute log of P(o|r,q)
#'
#' \code{yyx_log_P_o_given_r_q} computes log of P(o|r,q), given o, q
#'
#' This function uses an iterative algorithm to compute the log-likelihood for each possible real altCount r to the observed altCount o, modelling each base's baseQ (see Reference: \url{???}).
#' I think it was a marvellous "dynamic programming" algorithm coming to my mind, although later we found that LoFreq used a similar algorithm (Reference: \url{???}).
#'
#' Time complexity = O(depth^2); space complexity = O(depth)
#'
#' @param ref_baseQ_vec A numeric vector, the phred baseQ vector for ref alleles. (no +33 or +64)
#' @param alt_baseQ_vec A numeric vector, the phred baseQ vector for alt alleles. (no +33 or +64)
#' @section Note:
#' Input phred baseQ should be exactly -10*log(error_rate), +33 or +64 not allowed
#' @return A vector with length = depth + 1,
#' as a function of discrete 'real' altCount r.
#'
#' @seealso \code{yyx_log_P_o_given_r_q__c} for Rcpp version
#' @family mosaic model related functions
#'
#' @examples
#' yyx_log_P_o_given_r_q(rep(30,15), rep(20,12))
#' yyx_log_P_o_given_r_q__c(rep(30,15), rep(20,12))
#' #  [1] -55.2770497  -48.1970106 ... -94.1221201 -103.7369332 [28]
#'
yyx_log_P_o_given_r_q <- function(ref_baseQ_vec, alt_baseQ_vec){
	ref_count <- length(ref_baseQ_vec)
	alt_count <- length(alt_baseQ_vec)
	depth <- ref_count + alt_count
	ref_error_rate_vec <- 10^(-ref_baseQ_vec/10)
	alt_error_rate_vec <- 10^(-alt_baseQ_vec/10)
	
	tmpMat <- matrix(0, ncol=2, nrow=depth)
	# 1st column: P(o_i|r_i=ref)  ~ r+=0
	# 2nd column: P(o_i|r_i=alt)  ~ r+=1
	# i = 1:ref_count, o_i=ref
	# i = (ref_count+1):depth, o_i=alt
	if(ref_count > 0){
		tmpMat[1:ref_count, 1] <- 1 - ref_error_rate_vec
		tmpMat[1:ref_count, 2] <- ref_error_rate_vec
	}
	if(alt_count > 0){
		tmpMat[(ref_count+1):depth, 2] <- 1 - alt_error_rate_vec
		tmpMat[(ref_count+1):depth, 1] <- alt_error_rate_vec
	}
	# convert to log space
	tmpMat <- log(tmpMat)
	
	ans <- rep(-Inf, depth+2)
	# ans idx=1:(depth+2) for convenience, return(ans[-1])
	# P(o|r,q) as function of r(real_alt_count)=0:depth (idx=1:(depth+1))
	ans[2:3] <- tmpMat[1,]
	for(i in 2:depth){
		for(j in seq(i+2,2,by=-1)){
			ans[j] <- yyx_log_sum_exp( ans[c(j,j-1)] + tmpMat[i,] )
		}
	}
	return(ans[-1])
}

#' Compute log of P(r|theta,depth)
#'
#' \code{yyx_log_P_r_given_theta_depth} computes log of P(r|theta,depth), given theta, depth
#'
#' This function computes log of P(r|theta,depth) as a function of discrete r.
#' In fact, P(r|theta,depth) = theta^r * (1-theta)^(depth-r), 
#' thus, log P(r|theta,depth) = r * log(theta) + (depth-r) * log(1-theta)
#'
#' Time complexity = O(depth); space complexity = O(depth)
#'
#' @param theta A value, the specified theoretical allele fraction.
#' @param depth A value, the specified depth.
#' @return A vector with length = depth + 1,
#' as a function of discrete 'real' altCount r.
#'
#' @seealso \code{yyx_log_P_r_given_theta_depth__c} for Rcpp version
#' @family mosaic model related functions
#'
#' @examples
#' yyx_log_P_r_given_theta_depth(0.3, 20)
#' yyx_log_P_r_given_theta_depth__c(0.3, 20)
#' #  [1] -7.133499  -7.980797 ... -23.232158 -24.079456 [21]
#'
yyx_log_P_r_given_theta_depth <- function(theta, depth){
	r_vec <- 0:depth
	
	log_theta <- log(theta)
	if(theta==0) log_theta <- -1e30
	log_1_theta <- log(1 - theta)
	if(theta==1) log_1_theta <- -1e30
	
	r_vec * log_theta + (depth - r_vec) * log_1_theta
}

#' Compute log of P(o|theta,q)
#'
#' \code{yyx_log_P_o_given_theta_q} computes log of P(o|theta,q), given theta and baseQ vector
#'
#' This function wraps function \code{yyx_log_P_o_given_r_q} and \code{yyx_log_P_r_given_theta_depth}, to compute log of P(o|theta,q),
#' whereas \eqn{ P(o|\theta,q) = \sum_r P(r|\theta,depth) * P(o|r,q) }
#'
#' When input \code{log_P_o_given_r_q_vec} is provided, \code{ref_baseQ_vec} and \code{ref_baseQ_vec} will be ignored and thus can be skipped.
#' As the iterative step (function \code{yyx_log_P_o_given_r_q}) is slow (especially for high depth), it is better to pre-compute log_P_o_given_r_q_vec, when trying several theta for the same site, as shown in the code of funtion \code{yyx_loglikelihood_theta_splinefun}.
#'
#' Time complexity = [ O(depth^2) ] + O(depth); space complexity = O(depth)
#'
#' @param theta A value, the specified theoretical allele fraction.
#' @param ref_baseQ_vec A numeric vector, the phred baseQ vector for ref alleles. (no +33 or +64)
#' @param alt_baseQ_vec A numeric vector, the phred baseQ vector for alt alleles. (no +33 or +64)
#' @param log_P_o_given_r_q_vec A numeric vector with length = depth + 1, the pre-computed result vector of function \code{yyx_log_P_o_given_r_q}.
#' @return A value = log of P(o|theta,q)
#'
#' @seealso \code{yyx_log_P_o_given_theta_q__c} for Rcpp version
#' @family mosaic model related functions
#'
#' @examples
#' yyx_log_P_o_given_theta_q(0.3, rep(30,15), rep(20,12))
#' yyx_log_P_o_given_theta_q(0.3, log_P_o_given_r_q_vec = yyx_log_P_o_given_r_q(rep(30,15), rep(20,12)))
#' yyx_log_P_o_given_theta_q__c(0.3, yyx_log_P_o_given_r_q__c(rep(30,15), rep(20,12)))
#' #  -19.64743
#'
yyx_log_P_o_given_theta_q <- function(theta, ref_baseQ_vec, alt_baseQ_vec, log_P_o_given_r_q_vec=NULL){
	depth <- NA
	
	if(is.null(log_P_o_given_r_q_vec)){
		log_P_o_given_r_q_vec <- yyx_log_P_o_given_r_q(ref_baseQ_vec, alt_baseQ_vec)
		depth <- length(ref_baseQ_vec) + length(alt_baseQ_vec)
	}else{
		depth <- length(log_P_o_given_r_q_vec) - 1
	}
	
#	print(length(log_P_o_given_r_q_vec))
	log_P_r_given_theta_depth_vec <- yyx_log_P_r_given_theta_depth(theta, depth)
#	print(length(log_P_r_given_theta_depth_vec))
	stopifnot(length(log_P_o_given_r_q_vec)==length(log_P_r_given_theta_depth_vec))
	
	yyx_log_sum_exp( log_P_o_given_r_q_vec + log_P_r_given_theta_depth_vec )
}



#' Numerically compute log-likelihood for each theta
#'
#' \code{yyx_loglikelihood_theta_vec} numerically compute log-likelihood for each theta
#'
#' This function wraps function \code{yyx_log_P_o_given_r_q} and \code{yyx_log_P_o_given_theta_q},
#' traverses every theta in \code{theta_vec},
#' computes log-likelihood for each theta.
#'
#' The time complexity = O(depth^2) + O(#knots * depth)
#'
#' @param ref_baseQ_vec A numeric vector, the phred baseQ vector for ref alleles. (no +33 or +64)
#' @param alt_baseQ_vec A numeric vector, the phred baseQ vector for alt alleles. (no +33 or +64)
#' @param theta_vec A numeric vector, specifies the theta sample points.
#' @return A vector with length = length(theta_vec),
#' one log-likelihood value for each theta in \code{theta_vec}.
#'
#' @seealso \code{yyx_loglikelihood_theta_vec__c} for Rcpp version
#' @seealso \code{\link{yyx_loglikelihood_theta_splinefun}} wraps this function and fitted splinefun.
#' @family mosaic model spline-fit functions
#'
#' @examples
#' yyx_loglikelihood_theta_vec(rep(30,15), rep(20,12), seq(0,1,by=0.1))
#' #  [1] -55.27705  -28.30124 ... -35.79072 -103.73693 [10]
#'
#' yyx_loglikelihood_theta_vec(rep(30,15), rep(20,12), c(0,0.2,0.5,1))
#' #  -55.27705  -22.31696  -18.71497 -103.73693
#'
yyx_loglikelihood_theta_vec <- function(ref_baseQ_vec, alt_baseQ_vec, theta_vec){
	log_P_o_given_r_q_vec <- yyx_log_P_o_given_r_q(ref_baseQ_vec, alt_baseQ_vec)
	loglikelihood_vec <- unlist(lapply(theta_vec, function(theta){ yyx_log_P_o_given_theta_q(theta=theta, log_P_o_given_r_q_vec=log_P_o_given_r_q_vec) }))
	stopifnot(length(loglikelihood_vec)==length(theta_vec))
	loglikelihood_vec
}

#' Generate spline fitted function of log-likelihood of theta
#'
#' \code{yyx_loglikelihood_theta_splinefun} generates log-likelihood function of theta
#'
#' This function wraps function \code{yyx_loglikelihood_theta_vec},
#' traverses every theta in \code{theta_vec},
#' computes log-likelihood for each theta,
#' and finally fitted a spline function through these sample points.
#'
#' To avoid the log-likelihood numeric outlier at the boundary (0 and/or 1) when there is any baseQ = +Inf,
#' I first checked the input baseQ and then set the default theta_vec:
#' \enumerate{
#'   \item If no baseQ = +Inf, default theta_vec = seq(0, 1, length.out=knots);
#'   \item If existing ref baseQ = +Inf, the upper-bound was set to 1 - 1/2/knots;
#'   \item If existing alt baseQ = +Inf, the lower-bound was set to 1/2/knots.
#' }
#'
#' To avoid underflow in following analysis, 
#' I "normalize" the result to make the max log-likelihood = 0 (max likelihood = 1),
#' so only the relative value but not the absolute value is meaningful.
#'
#' The time complexity = O(depth^2) + O(#knots * depth) + O(splinefun for #knots)
#'
#' @param ref_baseQ_vec A numeric vector, the phred baseQ vector for ref alleles. (no +33 or +64)
#' @param alt_baseQ_vec A numeric vector, the phred baseQ vector for alt alleles. (no +33 or +64)
#' @param knots An integer. How many theta sample points should be computed?
#' @param theta_vec A numeric vector, specifies the theta sample points.
#'  When \code{theta_vec} is specified, \code{knots} is ignored
#' @param splinefun_par A list, any paramters passed to function \code{splinefun}
#' @return An R function (result of splinefun) of theta, restricted to [0,1]
#'
#' @seealso \code{\link{yyx_loglikelihood_theta_vec}} computes the log-likelihood of each theta in any specified theta_vec.
#' @seealso \code{yyx_loglikelihood_theta_splinefun__call_c} calls Rcpp version functions.
#' @family mosaic model spline-fit functions
#'
#' @examples
#' tmp_fun <- yyx_loglikelihood_theta_splinefun(rep(30,15), rep(20,12))
#' curve(tmp_fun, 0, 1, n=1001L)
#'
#' tmp_fun <- yyx_loglikelihood_theta_splinefun__call_c(rep(30,15), rep(20,12))
#' curve(tmp_fun, 0, 1, n=1001L, add=T, col='red', lty=2)
#' # two exact-overlapping log-likelihood curve
#'
yyx_loglikelihood_theta_splinefun <- function(ref_baseQ_vec, alt_baseQ_vec, knots = 1000, theta_vec = NULL, splinefun_par = list()){
	splinefun <- do.call(pryr::partial, c(splinefun, splinefun_par))
	
	if(is.null(theta_vec)){
		left_bound <- 0
		right_bound <- 1
		warn_str <- ""
		if(any(is.infinite(alt_baseQ_vec))){
			left_bound <- 1/2/knots
			warn_str <- paste0(warn_str, "As there are some alt baseQ = +Inf, I select theta_vec sampling from theta = ", left_bound, ".\n")
		}
		if(any(is.infinite(ref_baseQ_vec))){
			right_bound <- 1 - 1/2/knots
			warn_str <- paste0(warn_str, "As there are some ref baseQ = +Inf, I select theta_vec sampling to theta = ", right_bound, ".\n")
		}
		if(warn_str != ""){
			warn_str <- paste0(warn_str, "Thus, outerpolating to theta = 0 and/or 1 might introduce inaccuracy, especially when called by \"yyx_ref_het_alt_mosaic_posterior\" or \"yyx_wrapped_mosaic_hunter_for_one_site\".\nThis problem might be relieved by using more knots (eg. 10000).")
			warning(warn_str)
		}
		theta_vec <- seq(left_bound, right_bound, length.out=knots)
	}
	if(any(theta_vec < 0) || any(theta_vec > 1)){
		warning("input \"theta_vec\" out of [0,1]")
	}
	
#	log_P_o_given_r_q_vec <- yyx_log_P_o_given_r_q(ref_baseQ_vec, alt_baseQ_vec)
#	loglikelihood_vec <- unlist(lapply(theta_vec, function(theta){ yyx_log_P_o_given_theta_q(theta=theta, log_P_o_given_r_q_vec=log_P_o_given_r_q_vec) }))
	loglikelihood_vec <- yyx_loglikelihood_theta_vec(ref_baseQ_vec, alt_baseQ_vec, theta_vec)
	loglikelihood_vec <- loglikelihood_vec - max(loglikelihood_vec)
	stopifnot(length(theta_vec)==length(loglikelihood_vec))
	
	yyx_restrict_x_interval_function(splinefun(theta_vec, loglikelihood_vec), c(0,1), -Inf)
}

#' Generate spline fitted function of likelihood of theta
#'
#' \code{yyx_likelihood_theta_splinefun} generates likelihood function of theta
#'
#' This function wraps function \code{yyx_loglikelihood_theta_splinefun} and \code{yyx_exp_function},
#' to get fitted spline function for likelihood function of theta.
#'
#' Calling function \code{yyx_loglikelihood_theta_splinefun} then exponentiate it, 
#' to ensure the final value region >= 0.
#'
#' To avoid underflow in following analysis, 
#' I "normalize" the result to make the max likelihood = 1,
#' so only the relative value but not the absolute value is meaningful.
#'
#' The time complexity = O(depth^2) + O(#knots * depth) + O(splinefun for #knots)
#'
#' @param ref_baseQ_vec A numeric vector, the phred baseQ vector for ref alleles. (no +33 or +64)
#' @param alt_baseQ_vec A numeric vector, the phred baseQ vector for alt alleles. (no +33 or +64)
#' @param knots An integer. How many theta sample points should be computed?
#' @param theta_vec A numeric vector, specifies the theta sample points.
#'  When \code{theta_vec} is specified, \code{knots} is ignored
#' @param splinefun_par A list, any paramters passed to function \code{splinefun}
#' @return An R function (result of splinefun) of theta, restricted to [0,1]
#'
#' @seealso \code{\link{yyx_loglikelihood_theta_splinefun}} generates log-likelihood function of theta
#' @seealso \code{yyx_likelihood_theta_splinefun__call_c} calls Rcpp version functions.
#' @family mosaic model spline-fit functions
#'
#' @examples
#' tmp_fun <- yyx_likelihood_theta_splinefun(rep(30,15), rep(20,12))
#' curve(tmp_fun, 0, 1, n=1001L)
#'
#' tmp_fun <- yyx_likelihood_theta_splinefun__call_c(rep(30,15), rep(20,12))
#' curve(tmp_fun, 0, 1, n=1001L, add=T, col='red', lty=2)
#' # two exact-overlapping likelihood curve
#'
yyx_likelihood_theta_splinefun <- function(ref_baseQ_vec, alt_baseQ_vec, knots = 1000, theta_vec = NULL, splinefun_par = list()){
	yyx_exp_function(yyx_loglikelihood_theta_splinefun(ref_baseQ_vec, alt_baseQ_vec, knots = knots, theta_vec = theta_vec, splinefun_par = splinefun_par))
}

#sourceCpp("baseQ_Rcpp.20140918.cpp")

#' Generate spline fitted function of log-likelihood of theta
#'
#' \code{yyx_loglikelihood_theta_splinefun__call_c} generates log-likelihood function of theta
#'
#' This function wraps function \code{yyx_loglikelihood_theta_vec__c}
#' traverses every theta in \code{theta_vec},
#' computes log-likelihood for each theta,
#' and finally fitted a spline function through these sample points.
#'
#' To avoid underflow in following analysis, 
#' I "normalize" the result to make the max log-likelihood = 0 (max likelihood = 1),
#' so only the relative value but not the absolute value is meaningful.
#'
#' The time complexity = O(depth^2) + O(#knots * depth) + O(splinefun for #knots)
#'
#' @section Note:
#' For ultra high depth, uniformly sampled theta might not be the best choice.
#' So user can manually write his/her own function to mostly sample around the peak, 
#' call \code{yyx_loglikelihood_theta_vec__c}, and finally fitted by \code{splinefun}.
#'
#' @param ref_baseQ_vec A numeric vector, the phred baseQ vector for ref alleles. (no +33 or +64)
#' @param alt_baseQ_vec A numeric vector, the phred baseQ vector for alt alleles. (no +33 or +64)
#' @param knots An integer. How many theta sample points should be computed?
#' @param theta_vec A numeric vector, specifies the theta sample points.
#'  When \code{theta_vec} is specified, \code{knots} is ignored
#' @param splinefun_par A list, any paramters passed to function \code{splinefun}
#' @return An R function (result of splinefun) of theta, restricted to [0,1]
#'
#' @seealso \code{yyx_loglikelihood_theta_vec__c} for Rcpp version to compute the log-likelihood of each theta in any specified theta_vec.
#' @seealso \code{\link{yyx_loglikelihood_theta_splinefun}} calls pure R functions.
#' @family mosaic model spline-fit functions
#'
#' @examples
#' tmp_fun <- yyx_loglikelihood_theta_splinefun__call_c(rep(30,15), rep(20,12))
#' curve(tmp_fun, 0, 1, n=1001L, col='red', lty=2)
#' # one log-likelihood curve
#'
yyx_loglikelihood_theta_splinefun__call_c <- function(ref_baseQ_vec, alt_baseQ_vec, knots = 1000, theta_vec = NULL, splinefun_par = list()){
	splinefun <- do.call(pryr::partial, c(splinefun, splinefun_par))
	
	if(is.null(theta_vec)){
		left_bound <- 0
		right_bound <- 1
		warn_str <- ""
		if(any(is.infinite(alt_baseQ_vec))){
			left_bound <- 1/2/knots
			warn_str <- paste0(warn_str, "As there are some alt baseQ = +Inf, I select theta_vec sampling from theta = ", left_bound, ".\n")
		}
		if(any(is.infinite(ref_baseQ_vec))){
			right_bound <- 1 - 1/2/knots
			warn_str <- paste0(warn_str, "As there are some ref baseQ = +Inf, I select theta_vec sampling to theta = ", right_bound, ".\n")
		}
		if(warn_str != ""){
			warn_str <- paste0(warn_str, "Thus, outerpolating to theta = 0 and/or 1 might introduce inaccuracy, especially when called by \"yyx_ref_het_alt_mosaic_posterior\" or \"yyx_wrapped_mosaic_hunter_for_one_site\".\nThis problem might be relieved by using more knots (eg. 10000).")
			warning(warn_str)
		}
		theta_vec <- seq(left_bound, right_bound, length.out=knots)
	}
	if(any(theta_vec < 0) || any(theta_vec > 1)){
		warning("input \"theta_vec\" out of [0,1]")
	}
	
	loglikelihood_vec <- yyx_loglikelihood_theta_vec__c(ref_baseQ_vec, alt_baseQ_vec, theta_vec)
	loglikelihood_vec <- loglikelihood_vec - max(loglikelihood_vec)
	stopifnot(length(theta_vec)==length(loglikelihood_vec))
	
	yyx_restrict_x_interval_function(splinefun(theta_vec, loglikelihood_vec), c(0,1), -Inf)
}

#' Generate spline fitted function of likelihood of theta
#'
#' \code{yyx_likelihood_theta_splinefun__call_c} generates likelihood function of theta
#'
#' This function wraps function \code{yyx_loglikelihood_theta_splinefun__call_c} and \code{yyx_exp_function},
#' to get fitted spline function for likelihood function of theta.
#'
#' Calling function \code{yyx_loglikelihood_theta_splinefun__call_c} then exponentiate it, 
#' to ensure the final value region >= 0
#'
#' To avoid underflow in following analysis, 
#' I "normalize" the result to make the max likelihood = 1,
#' so only the relative value but not the absolute value is meaningful.
#'
#' The time complexity = O(depth^2) + O(#knots * depth) + O(splinefun for #knots)
#'
#' @param ref_baseQ_vec A numeric vector, the phred baseQ vector for ref alleles. (no +33 or +64)
#' @param alt_baseQ_vec A numeric vector, the phred baseQ vector for alt alleles. (no +33 or +64)
#' @param knots An integer. How many theta sample points should be computed?
#' @param theta_vec A numeric vector, specifies the theta sample points.
#'  When \code{theta_vec} is specified, \code{knots} is ignored
#' @param splinefun_par A list, any paramters passed to function \code{splinefun}
#' @return An R function (result of splinefun) of theta, restricted to [0,1]
#'
#' @seealso \code{\link{yyx_loglikelihood_theta_splinefun}} generates log-likelihood function of theta
#' @seealso \code{\link{yyx_likelihood_theta_splinefun}} calls pure R functions.
#' @family mosaic model spline-fit functions
#'
#' @examples
#' tmp_fun <- yyx_likelihood_theta_splinefun__call_c(rep(30,15), rep(20,12))
#' curve(tmp_fun, 0, 1, n=1001L, col='red', lty=2)
#' # one likelihood curve
#'
yyx_likelihood_theta_splinefun__call_c <- function(ref_baseQ_vec, alt_baseQ_vec, knots = 1000, theta_vec = NULL, splinefun_par = list()){
	yyx_exp_function(yyx_loglikelihood_theta_splinefun__call_c(ref_baseQ_vec, alt_baseQ_vec, knots = knots, theta_vec = theta_vec, splinefun_par =splinefun_par))
}


### function parser

#' Sweep negative values to be zero
#'
#' \code{yyx_keep_positive_function} wraps an R function and sweeps any negative values to be zero
#'
#' @param f An R function
#' @return An wrapped R function, with original negative results to be zero
#'
#' The parser result also contains two additional attributes: "function_parser" and "original_function".
#'
#' @seealso \code{\link{yyx_restrict_x_interval_function}}, \code{\link{yyx_restrict_y_interval_function}}
#' @family function parser functions
#'
#' @examples
#' curve(sin(x), 0, 4*pi)
#' curve(yyx_keep_positive_function(sin)(x), 0, 4*pi, add=T, col='red', lty=2)
#' # black solid : sin,  red dashed : yyx_keep_positive_function(sin)
#'
yyx_keep_positive_function <- function(f){
	ans <- function(...){
		tmp <- f(...)
		tmp[tmp < 0] <- 0
		tmp
	}
	attr(ans, "function_parser") <- "yyx_keep_positive_function"
	attr(ans, "original_function") <- f
	ans
}

#' Exponentiate the value
#'
#' \code{yyx_exp_function} wraps an R function and exponentiates the result value
#'
#' If the input function \code{f} is a result from \code{yyx_log_function},
#' this function will retrieve and return the "original_function" attribute.
#'
#' @param f An R function
#' @return An wrapped R function, exponentiates the original result value
#'
#' The parser result also contains two additional attributes: "function_parser" and "original_function".
#'
#' @seealso \code{\link{yyx_log_function}}
#' @family function parser functions
#'
#' @examples
#' curve(sin(x), 0, 4*pi, ylim=c(-1,3))
#' curve(yyx_exp_function(sin)(x), 0, 4*pi, add=T, col='red', lty=2)
#' # black solid : sin,  red dashed : yyx_exp_function(sin)
#'
yyx_exp_function <- function(f){
	if(!is.null(attr(f, "function_parser")) && attr(f, "function_parser")=="yyx_log_function"){
		return(attr(f, "original_function"))
	}
	ans <- function(...){
		exp(f(...))
	}
	attr(ans, "function_parser") <- "yyx_exp_function"
	attr(ans, "original_function") <- f
	ans
}

#' Logarithmize the value
#'
#' \code{yyx_log_function} wraps an R function and logarithmize the result value
#'
#' If the input function \code{f} is a result from \code{yyx_exp_function},
#' this function will retrieve and return the "original_function" attribute.
#'
#' @param f An R function
#' @return An wrapped R function, logarithmize the original result value
#'
#' The parser result also contains two additional attributes: "function_parser" and "original_function".
#'
#' @seealso \code{\link{yyx_log_function}}
#' @family function parser functions
#'
#' @examples
#' curve(exp(x), -1, 3, ylim=c(-1,10))
#' curve(yyx_log_function(exp)(x), -1, 3, add=T, col='red', lty=2)
#' # black solid : exp,  red dashed : yyx_log_function(exp)
#'
yyx_log_function <- function(f){
	if(!is.null(attr(f, "function_parser")) && attr(f, "function_parser")=="yyx_exp_function"){
		return(attr(f, "original_function"))
	}
	ans <- function(...){
		log(f(...))
	}
	attr(ans, "function_parser") <- "yyx_log_function"
	attr(ans, "original_function") <- f
	ans
}

#' Restrict the x (definitional domain)
#'
#' \code{yyx_restrict_x_interval_function} wraps an R function and restricts its definitional domain
#'
#' @param f An R function, with only one x
#' @param x_interval A numeric vector, the specified valid definitional domain
#' @param outside_value A numeric value, the cast value when x is outside of \code{x_interval}
#' @return The wrapped R function
#'
#' The parser result also contains two additional attributes: "function_parser" and "original_function".
#'
#' @seealso \code{\link{yyx_restrict_y_interval_function}}, \code{\link{yyx_keep_positive_function}}
#' @family function parser functions
#'
#' @examples
#' curve(sin(x), 0, 4*pi)
#' curve(yyx_restrict_x_interval_function(sin, c(1,7), -0.5)(x), 0, 4*pi, add=T, col='red', lty=2)
#' # black solid : sin,  red dashed : yyx_restrict_x_interval_function(sin, c(1,7), -0.5)
#'
yyx_restrict_x_interval_function <- function(f, x_interval, outside_value=NA){
	ans <- function(x, ...){
		ans <- rep(outside_value, length(x))
		bool_idx <- yyx_is_within_range(x, x_interval)
		ans[bool_idx] <- f(x[bool_idx], ...)
		ans
	}
	attr(ans, "function_parser") <- "yyx_restrict_x_interval_function"
	attr(ans, "original_function") <- f
	ans
}

#' Restrict the y (value range)
#'
#' \code{yyx_restrict_y_interval_function} wraps an R function and restricts its value range
#'
#' @param f An R function
#' @param y_interval A numeric vector, the specified valid value range
#' @param less_value A numeric value, the cast value when original y is less than \code{y_interval}
#' @param greater_value A numeric value, the cast value when original y is greater than \code{y_interval}
#' @return The wrapped R function
#'
#' The parser result also contains two additional attributes: "function_parser" and "original_function".
#'
#' @seealso \code{\link{yyx_restrict_x_interval_function}}, \code{\link{yyx_keep_positive_function}}
#' @family function parser functions
#'
#' @examples
#' curve(sin(x), 0, 4*pi)
#' curve(yyx_restrict_y_interval_function(sin, c(-0.5,0.5), -0.9)(x), 0, 4*pi, n=1001L, add=T, col='red', lty=2)
#' # black solid : sin,  red dashed : yyx_restrict_y_interval_function(sin, c(-0.5,0.5), -0.9)
#'
yyx_restrict_y_interval_function <- function(f, y_interval, less_value = min(y_interval), greater_value = max(y_interval)){
	y_interval <- range(y_interval)
	ans <- function(...){
		ans <- f(...)
		ans[ans>max(y_interval)] <- greater_value
		ans[ans<min(y_interval)] <- less_value
		ans
	}
	attr(ans, "function_parser") <- "yyx_restrict_y_interval_function"
	attr(ans, "original_function") <- f
	ans
}



#' Multiply two functions
#'
#' \code{yyx_multiply_two_functions} multiply the return value from input two functions
#'
#' @param funA An R function
#' @param funB An R function
#' @return An wrapped R function, with return value = funA(...) * funB(...)
#'
#' The parser result also contains two additional attributes: "function_parser" and "original_function".
#'
#' @family function parser functions
#'
#' @examples
#' curve(sin(x), 0, 4*pi)
#' curve(cos(x), 0, 4*pi, add=T, col='blue')
#' curve(yyx_multiply_two_functions(sin,cos)(x), 0, 4*pi, add=T, col='red', lwd=2, lty=2)
#' curve(sin(x)*cos(x), 0, 4*pi, add=T, col='yellow2', lwd=2, lty=3)
#' # black solid : sin,  blue solid : cos
#' # red dashed & yellow dashed: yyx_multiply_two_functions(sin,cos) = sin(x) * cos(x)
#'
yyx_multiply_two_functions <- function(funA, funB){
	ans <- function(...){
		funA(...) * funB(...)
	}
	attr(ans, "function_parser") <- "yyx_multiply_two_functions"
	attr(ans, "original_function") <- c(funA, funB)
	ans
}



### distribution related functions

#' Compute the normalization factor (integral area)
#'
#' \code{yyx_calculate_normalization_factor} computes the normalization factor (integral area)
#' using numeric integration (ie. function \code{integrate})
#'
#' @param f An R function, such as (unnormalized) distribution density function
#' @param integrate_interval A numeric vector, the specified numeric integration interval of x
#' @param input_log_fun A bool value. Is input function in log-spece?
#' @param warn_negative A bool value. Shouls I throw a warning, when the final result is negative?
#' @param integrate_par A list, any paramters passed to function \code{integrate}
#' @return A numeric value = normalization factor (integral area)
#'
#' @seealso \code{\link{yyx_normalize_distribution_function}}, \code{\link{yyx_posterior_mean}}
#' @family distribution related functions
#'
#' @examples
#' yyx_calculate_normalization_factor(sin, c(0, 2*pi))
#' # 2.032977e-16
#'
#' yyx_calculate_normalization_factor(dnorm, c(0, 100))
#' # 0.5
#'
yyx_calculate_normalization_factor <- function(f, integrate_interval, input_log_fun = FALSE, warn_negative = TRUE, integrate_par=list(rel.tol=.Machine$double.eps^0.5)){
	integrate <- do.call(pryr::partial, c(integrate, integrate_par))
	
	normalization_factor <- NA
	if(input_log_fun){   # input_log_fun == TRUE
		f_exp <- yyx_exp_function(f)
		normalization_factor <- integrate(f_exp, min(integrate_interval), max(integrate_interval), subdivisions = 1000L)$value
		if(warn_negative && normalization_factor < 0){
			warning("The calculated normalization_factor is positive,\n    which is wired for the input log-likelihood function;\n  and you may need to check the input function")
		}
	}else{
		normalization_factor <- integrate(f, min(integrate_interval), max(integrate_interval), subdivisions = 1000L)$value
		if(warn_negative && normalization_factor < 0){
			warning("The calculated normalization_factor is negative,\n    which might indicate that you passed in a log-likelihood function\n    but not a requested likelihood (density) function;\n  and you may try \"input_log_fun = TRUE\"")
		}
	}
	normalization_factor
}

#' Normalize a distribution function
#'
#' \code{yyx_normalize_distribution_function} wraps input distribution function
#' by dividing the normalization factor (calling function \code{yyx_calculate_normalization_factor})
#'
#' @param f An R function, such as (unnormalized) distribution density function
#' @param integrate_interval A numeric vector, the specified numeric integration interval of x
#'  for computing the normalization factor
#' @param input_log_fun A bool value. Is input function in log-spece?
#' @param output_log_fun A bool value. Should output function be in log-spece?
#' @param warn_negative A bool value. Shouls I throw a warning, when the final result is negative?
#' @param integrate_par A list, any paramters passed to function \code{integrate}
#' @return A numeric value = normalization factor (integral area)
#'
#' @seealso \code{\link{yyx_calculate_normalization_factor}}
#' @family distribution related functions
#'
#' @examples
#' curve(dnorm, -10, +10, ylim=c(0,0.9))
#' curve(yyx_normalize_distribution_function(dnorm, c(0,100))(x), -10, +10, add=T, col='red', lty=2)
#' # black solid : dnorm,  red dashed : yyx_normalize_distribution_function(dnorm, c(0,100))
#'
yyx_normalize_distribution_function <- function(f, integrate_interval, input_log_fun = FALSE, output_log_fun = input_log_fun, warn_negative = TRUE, integrate_par=list(rel.tol=.Machine$double.eps^0.5)){
	if(input_log_fun){   # input_log_fun == TRUE
		normalization_factor <- yyx_calculate_normalization_factor(f, integrate_interval, input_log_fun = input_log_fun, warn_negative = warn_negative, integrate_par = integrate_par)
		if(output_log_fun){   # output_log_fun == TRUE
			function(...){
				f(...) - log(normalization_factor)
			}
		}else{   # output_log_fun == FALSE
			function(...){
				yyx_exp_function(f)(...) / normalization_factor
			}
		}
	}else{   # input_log_fun == FALSE
		normalization_factor <- yyx_calculate_normalization_factor(f, integrate_interval, input_log_fun = input_log_fun, warn_negative = warn_negative, integrate_par = integrate_par)
		if(output_log_fun){   # output_log_fun == TRUE
			function(...){
				yyx_log_function(f)(...) - log(normalization_factor)
			}
		}else{   # output_log_fun == FALSE
			function(...){
				f(...) / normalization_factor
			}
		}
	}
}

#' Compute the mean of the (posterior) distribution
#'
#' \code{yyx_posterior_mean} computes the mean of given distribution, 
#' by calling function \code{yyx_calculate_normalization_factor}
#'
#' @param f An R function, such as (unnormalized) distribution density function
#' @param integrate_interval A numeric vector, the specified numeric integration interval of x
#' @param input_log_fun A bool value. Is input function in log-spece?
#' @param integrate_par A list, any paramters passed to function \code{integrate}
#' @return A numeric value = (posterior) mean
#'
#' @seealso \code{\link{yyx_calculate_normalization_factor}}
#' @family distribution related functions
#'
#' @examples
#' yyx_posterior_mean(sin, c(0,pi)) * 2
#' # 3.141593
#'
#' yyx_posterior_mean(sin, c(0,2*pi))
#' # -3.090633e+16
#'
#' yyx_posterior_mean(dnorm, c(-100,100))
#' # 0
#'
#' yyx_posterior_mean(function(x) dnorm(x, log=T), c(-100,100), input_log_fun = T)
#' # 0
#'
yyx_posterior_mean <- function(f, integrate_interval, input_log_fun = FALSE, integrate_par=list(rel.tol=.Machine$double.eps^0.5)){
	integrate_interval <- range(integrate_interval)
	integrate <- do.call(pryr::partial, c(integrate, integrate_par))
	
	normalization_factor <- yyx_calculate_normalization_factor(f, integrate_interval, input_log_fun = input_log_fun, integrate_par = integrate_par)
	f_multiple_x <- function(x, ...){
		x * f(x, ...)
	}
	if(input_log_fun==TRUE){
		f_multiple_x <- function(x, ...){
			x * yyx_exp_function(f)(x, ...)
		}
	}
	summation_factor <- yyx_calculate_normalization_factor(f_multiple_x, integrate_interval, input_log_fun = FALSE, warn_negative = FALSE, integrate_par = integrate_par)
	
	summation_factor / normalization_factor
}


#' Compute the credible interval on distribution function
#'
#' \code{yyx_get_credible_interval} numerically computes the credible interval
#' on a given (unnormalized) distribution function
#'
#' The credible interval was computed by
#' \enumerate{
#'   \item normalizing (calling \code{yyx_calculate_normalization_factor})
#'   \item finding the maximum (calling \code{optimize}) on log distribution
#'   \item finding the left and right bound of credible interval (calling \code{uniroot})
#' }
#'
#' @param f An R function, (unnormalized) distribution density function
#' @param integrate_interval A numeric vector, the specified numeric integration interval of x
#' @param conf_level A numeric value in (0,1), confidence level of the interval.
#' @param optimize_uniroot_interval_min A numeric value, the left searching bound for \code{optimize} and \code{uniroot}
#' @param optimize_uniroot_interval_max A numeric value, the right searching bound for \code{optimize} and \code{uniroot}
#' @param alternative A character string specifying the alternative hypothesis,
#'  must be one of "two.sided" (default), "greater" or "less".
#' @param optimize_interval A numeric vector, the specified interval of x for \code{optimize}
#' @param uniroot_interval A numeric vector, the specified interval of x for \code{uniroot}
#' @param integrate_par A list, any paramters passed to function \code{integrate}
#' @param optimize_par A list, any paramters passed to function \code{optimize}
#' @param uniroot_par A list, any paramters passed to function \code{uniroot}
#' @return A list, containing MLE(= MAP estimate), CI, conf_level, alternative, posterior_mean
#'
#' @seealso \code{\link{yyx_get_posterior_p_value}}, \code{\link{yyx_calculate_normalization_factor}}
#' @family distribution related functions
#'
#' @examples
#' yyx_get_credible_interval(dnorm, c(-100,100))
#' qnorm(c(0.025, 0.975))
#' #  -1.959964  1.959964
#'
yyx_get_credible_interval <- function(f, integrate_interval, conf_level=0.95, optimize_uniroot_interval_min=-100, optimize_uniroot_interval_max=100, alternative = c("two_sided", "less", "greater"), optimize_interval = integrate_interval, uniroot_interval = integrate_interval, integrate_par=list(rel.tol=.Machine$double.eps^0.5), optimize_par=list(tol=.Machine$double.eps^0.5), uniroot_par=list(tol=.Machine$double.eps^0.5)){
	integrate_interval <- range(integrate_interval)
	optimize_interval <- range(optimize_interval)
	uniroot_interval <- range(uniroot_interval)
	if(optimize_interval[1] < optimize_uniroot_interval_min) optimize_interval[1] <- optimize_uniroot_interval_min
	if(optimize_interval[2] > optimize_uniroot_interval_max) optimize_interval[2] <- optimize_uniroot_interval_max
	if(uniroot_interval[1] < optimize_uniroot_interval_min) uniroot_interval[1] <- optimize_uniroot_interval_min
	if(uniroot_interval[2] > optimize_uniroot_interval_max) uniroot_interval[2] <- optimize_uniroot_interval_max
	
	integrate <- do.call(pryr::partial, c(integrate, integrate_par))
	optimize <- do.call(pryr::partial, c(optimize, optimize_par))
	uniroot <- do.call(pryr::partial, c(uniroot, uniroot_par))
	
	alternative <- match.arg(alternative)
	
#	normalization_factor <- integrate(f, integrate_interval[1], integrate_interval[2], subdivisions = 1000L)$value
	normalization_factor <- yyx_calculate_normalization_factor(f, integrate_interval, input_log_fun = FALSE, integrate_par = integrate_par)
	optimize_max_result <- optimize(yyx_log_function(f), optimize_interval, maximum=TRUE)
#	print(optimize_max_result)
	mid_max_x <- optimize_max_result$maximum
	if(yyx_p_distr(mid_max_x, f, integrate_interval, integrate_par) - 0.5 >= .Machine$double.eps^0.5){
		warning(paste0("the normalization factor (numerical integral) calculated by integrate might be wrong (yyx_p_distr != 0.5), and you may try to specify a shorter integrate_interval to fix it\n"))
	}
	if(any(abs(mid_max_x - optimize_interval)<=.Machine$double.eps^0.5)){
		warning(paste0("the MLE (",mid_max_x,") found by optimize might be wrong, and you may specify a shorter optimize_interval to fix it\n"))
	}
	
	get_right_x_given_left_x <- function(left_x, warning_on = TRUE){
		if( f(left_x) < f(max(uniroot_interval)) ){
			max(uniroot_interval)
		}else if( f(left_x) > f(mid_max_x) ){
			if(warning_on){
				warning(paste0("the MLE (",mid_max_x,") found by optimize might be wrong, and you may specify a shorter optimize_interval to fix it\n  because the function value of this left_x (",left_x,") is greater than the function value of the MLE\n"))
			}
			mid_max_x
		}else{
			uniroot(function(right_x){ f(right_x) - f(left_x) }, c(mid_max_x, uniroot_interval[2]))$root
		}
	}
	
	left_x_estimate <- right_x_estimate <- NA
	if(alternative == "two_sided"){
		left_x_estimate <- uniroot_interval[1];
		if(integrate(f, left_x_estimate, get_right_x_given_left_x(left_x_estimate))$value / normalization_factor > conf_level){
			left_x_estimate <- uniroot(function(left_x){ integrate(f, left_x, get_right_x_given_left_x(left_x, warning_on=FALSE))$value / normalization_factor - conf_level}, c(uniroot_interval[1], mid_max_x))$root
			right_x_estimate <- get_right_x_given_left_x(left_x_estimate)
		}else{
			right_x_estimate <- uniroot(function(right_x){ integrate(f, left_x_estimate, right_x)$value / normalization_factor - conf_level}, uniroot_interval)$root
		}
	}else if(alternative == "greater"){
		right_x_estimate <- integrate_interval[2]
		left_x_estimate <- uniroot(function(left_x){ integrate(f, left_x, right_x_estimate)$value / normalization_factor - conf_level}, uniroot_interval)$root
	}else if(alternative == "less"){
		left_x_estimate <- integrate_interval[1]
		right_x_estimate <- uniroot(function(right_x){ integrate(f, left_x_estimate, right_x)$value / normalization_factor - conf_level}, uniroot_interval)$root
	}else{
		stop(paste0("surprising to be here: unrecognized alternative = \"", alternative, "\""))
	}
	MLE <- mid_max_x
	CI <- c(left_x_estimate, right_x_estimate)
	posterior_mean <- yyx_posterior_mean(f, integrate_interval, input_log_fun = FALSE, integrate_par = integrate_par)
	tmp <- list(MLE=MLE, CI=CI, conf_level=conf_level, alternative=alternative, posterior_mean=posterior_mean)
	tmp
}

#' Compute the "posterior" p-value on a distribution
#'
#' \code{yyx_get_posterior_p_value} numerically computes the "posterior" p-value
#' on a given (unnormalized) distribution function
#'
#' The "posterior" p-value was computed by
#' \enumerate{
#'   \item normalizing (calling \code{yyx_calculate_normalization_factor})
#'   \item finding the maximum (calling \code{optimize}) on log distribution
#'   \item finding the reflecting position with equal density (calling \code{uniroot})
#'   \item compute the two-tailed (or one-tailed) p-value (calling \code{integrate})
#' }
#'
#' @section Note:
#' If given \code{x} is out of \code{integrate_interval}, strange value might be returned.
#'
#' @param x A numeric value (or vector), the "observed" x (quantile) for p-value computation.
#' @param f An R function, (unnormalized) distribution density function
#' @param integrate_interval A numeric vector, the specified numeric integration interval of x
#' @param optimize_uniroot_interval_min A numeric value, the left searching bound for \code{optimize} and \code{uniroot}
#' @param optimize_uniroot_interval_max A numeric value, the right searching bound for \code{optimize} and \code{uniroot}
#' @param alternative A character string specifying the alternative hypothesis,
#'  must be one of "two.sided" (default), "greater" or "less".
#' @param optimize_interval A numeric vector, the specified interval of x for \code{optimize}
#' @param uniroot_interval A numeric vector, the specified interval of x for \code{uniroot}
#' @param integrate_par A list, any paramters passed to function \code{integrate}
#' @param optimize_par A list, any paramters passed to function \code{optimize}
#' @param uniroot_par A list, any paramters passed to function \code{uniroot}
#' @return A numeric value (or vector), the "posterior" p-value(s)
#'
#' @seealso \code{\link{yyx_get_credible_interval}}, \code{\link{yyx_calculate_normalization_factor}}
#' @family distribution related functions
#'
#' @examples
#' yyx_get_posterior_p_value(0, dnorm, c(-100,100))
#' pnorm(0) * 2
#' # 1
#'
#' yyx_get_posterior_p_value(-1, dnorm, c(-100,100))
#' pnorm(-1) * 2
#' # 0.3173105
#'
yyx_get_posterior_p_value <- function(x, f, integrate_interval, optimize_uniroot_interval_min = -100, optimize_uniroot_interval_max = +100, alternative = c("two_sided", "less", "greater"), optimize_interval = integrate_interval, uniroot_interval = integrate_interval, integrate_par=list(rel.tol=.Machine$double.eps^0.5), optimize_par=list(tol=.Machine$double.eps^0.5), uniroot_par=list(tol=.Machine$double.eps^0.5)){
	integrate_interval <- range(integrate_interval)
	optimize_interval <- range(optimize_interval)
	uniroot_interval <- range(uniroot_interval)
	if(optimize_interval[1] < optimize_uniroot_interval_min) optimize_interval[1] <- optimize_uniroot_interval_min
	if(optimize_interval[2] > optimize_uniroot_interval_max) optimize_interval[2] <- optimize_uniroot_interval_max
	if(uniroot_interval[1] < optimize_uniroot_interval_min) uniroot_interval[1] <- optimize_uniroot_interval_min
	if(uniroot_interval[2] > optimize_uniroot_interval_max) uniroot_interval[2] <- optimize_uniroot_interval_max
	
	integrate <- do.call(pryr::partial, c(integrate, integrate_par))
	optimize <- do.call(pryr::partial, c(optimize, optimize_par))
	uniroot <- do.call(pryr::partial, c(uniroot, uniroot_par))
	
	alternative <- match.arg(alternative)
	
	if(any(!yyx_is_within_range(x, integrate_interval))){
		warning("some given x is out of the integrate_interval, strange value might be returned.\n")
	}
	
#	normalization_factor <- integrate(f, min(integrate_interval), max(integrate_interval), subdivisions = 1000L)$value
	normalization_factor <- yyx_calculate_normalization_factor(f, integrate_interval, input_log_fun = FALSE, integrate_par = integrate_par)
	optimize_max_result <- optimize(yyx_log_function(f), optimize_interval, maximum=TRUE)
#	print(optimize_max_result)
	mid_max_x <- optimize_max_result$maximum
	
	if(yyx_p_distr(mid_max_x, f, integrate_interval, integrate_par) - 0.5 >= .Machine$double.eps^0.5){
		warning(paste0("the normalization factor (numerical integral) calculated by integrate might be wrong (yyx_p_distr != 0.5), and you may try to specify a shorter integrate_interval to fix it\n"))
	}
	if(any(abs(mid_max_x - optimize_interval)<=.Machine$double.eps^0.5)){
		warning(paste0("the MLE (",mid_max_x,") found by optimize might be wrong, and you may specify a shorter optimize_interval to fix it\n"))
	}
	
	get_right_x_given_left_x <- function(left_x, warning_on = TRUE){
		if( f(left_x) < f(max(uniroot_interval)) ){
			max(uniroot_interval)
		}else if( f(left_x) > f(mid_max_x) ){
			if(warning_on){
				warning(paste0("the MLE (",mid_max_x,") found by optimize might be wrong, and you may specify a shorter optimize_interval to fix it\n  because the function value of this left_x (",left_x,") is greater than the function value of the MLE\n"))
			}
			mid_max_x
		}else{
			uniroot(function(right_x){ f(right_x) - f(left_x) }, c(mid_max_x, uniroot_interval[2]) )$root
		}
	}
	get_left_x_given_right_x <- function(right_x, warning_on = TRUE){
		if( f(right_x) < f(min(uniroot_interval)) ){
			min(uniroot_interval)
		}else if( f(right_x) > f(mid_max_x) ){
			if(warning_on){
				warning(paste0("the MLE (",mid_max_x,") found by optimize might be wrong, and you may specify a shorter optimize_interval to fix it\n  because the function value of this right_x (",right_x,") is greater than the function value of the MLE\n"))
			}
			mid_max_x
		}else{
			uniroot(function(left_x){ f(right_x) - f(left_x) }, c(uniroot_interval[1], mid_max_x) )$root
		}
	}
	
	if(alternative == "two_sided"){
		tmp_DF <- data.frame(left_x = x, right_x = NA)
		tmp_DF$right_x[tmp_DF$left_x < mid_max_x] <- unlist(lapply(tmp_DF$left_x[tmp_DF$left_x < mid_max_x], get_right_x_given_left_x))
		tmp_DF$right_x[tmp_DF$left_x > mid_max_x] <- tmp_DF$left_x[tmp_DF$left_x > mid_max_x]
		tmp_DF$left_x[tmp_DF$left_x > mid_max_x] <- unlist(lapply(tmp_DF$right_x[tmp_DF$left_x > mid_max_x], get_left_x_given_right_x))
		tmp_DF$right_x[tmp_DF$left_x == mid_max_x] <- tmp_DF$left_x[tmp_DF$left_x == mid_max_x]
		
		apply(tmp_DF, 1, function(tmp_vec){
			( integrate(f, min(integrate_interval), tmp_vec[1])$value + integrate(f, tmp_vec[2], max(integrate_interval))$value ) / normalization_factor
		})
	}else if(alternative == "greater"){
		tmp <- unlist(lapply(x, function(this_x){
			integrate(f, this_x, max(integrate_interval))$value / normalization_factor
		}))
		stopifnot(length(tmp) == length(x))
		tmp
	}else if(alternative == "less"){
		tmp <- unlist(lapply(x, function(this_x){
			integrate(f, min(integrate_interval), this_x)$value / normalization_factor
		}))
		stopifnot(length(tmp) == length(x))
		tmp
	}else{
		stop(paste0("surprising to be here: unrecognized alternative = \"", alternative, "\""))
	}
}


#' Numerical(empirical) cumulative distribution function value(s)
#'
#' \code{yyx_p_distr} numerically computes the cumulative distribution function values
#' on a given (unnormalized) distribution function
#'
#' The cumulative distribution function value was computed by
#' \enumerate{
#'   \item normalizing (calling \code{yyx_calculate_normalization_factor})
#'   \item compute the cumulative distribution function value (calling \code{integrate})
#' }
#'
#' @section Note:
#' If given \code{q} is out of \code{integrate_interval}, 0 or 1 would be returned.
#'
#' @param q A numeric value (or vector), the quantiles.
#' @param f An R function, (unnormalized) distribution density function
#' @param integrate_interval A numeric vector, the specified numeric integration interval of x
#' @param integrate_par A list, any paramters passed to function \code{integrate}
#' @return A numeric value (or vector), the cumulative distribution function value(s)
#'
#' @seealso \code{\link{yyx_q_distr}}, \code{\link{yyx_d_distr}}
#' @seealso \code{\link{yyx_get_credible_interval}}, \code{\link{yyx_calculate_normalization_factor}}
#' @family distribution related functions
#'
#' @examples
#' yyx_p_distr(0, dnorm, c(-100,100))
#' pnorm(0)
#' # 0.5
#'
#' yyx_p_distr(-1, dnorm, c(-100,100))
#' pnorm(-1)
#' # 0.1586553
#'
yyx_p_distr <- function(q, f, integrate_interval, integrate_par=list(rel.tol=.Machine$double.eps^0.5)){
	integrate_interval <- range(integrate_interval)
	
	integrate <- do.call(pryr::partial, c(integrate, integrate_par))
	
	normalization_factor <- yyx_calculate_normalization_factor(f, integrate_interval, input_log_fun = FALSE, integrate_par = integrate_par)
	
	tmp <- unlist(lapply(q, function(this_q){
		if(this_q > integrate_interval[1]){
			if(this_q < integrate_interval[2]){
				left_area <- yyx_calculate_normalization_factor(f, c(integrate_interval[1], this_q), input_log_fun = FALSE, integrate_par = integrate_par)
				left_area / normalization_factor
			}else{   # this_q >= integrate_interval[2]
				1
			}
		}else{   # this_q <= integrate_interval[1]
			0
		}
	}))
	stopifnot(length(tmp) == length(q))
	tmp
}

#' Numerical(empirical) quantile function value(s)
#'
#' \code{yyx_q_distr} numerically computes the quantile function values
#' on a given (unnormalized) distribution function
#'
#' The quantile function value was computed by
#' \enumerate{
#'   \item normalizing (calling \code{yyx_calculate_normalization_factor})
#'   \item finding the position with the corresponding cumulative probability
#'           (calling \code{uniroot} and \code{integrate})
#'   \item compute the two-tailed (or one-tailed) p-value (calling \code{integrate})
#' }
#'
#' @section Note:
#' \code{uniroot_interval} is suggested to be the same as \code{integrate_interval}
#'
#' @param p A numeric value (or vector), the cumulative probability(ies).
#' @param f An R function, (unnormalized) distribution density function
#' @param integrate_interval A numeric vector, the specified numeric integration interval of x
#' @param uniroot_interval A numeric vector, the specified interval of x for \code{uniroot}
#' @param integrate_par A list, any paramters passed to function \code{integrate}
#' @param uniroot_par A list, any paramters passed to function \code{uniroot}
#' @return A numeric value (or vector), the quantile values
#'
#' @seealso \code{\link{yyx_p_distr}}, \code{\link{yyx_d_distr}}
#' @seealso \code{\link{yyx_get_credible_interval}}, \code{\link{yyx_calculate_normalization_factor}}
#' @family distribution related functions
#'
#' @examples
#' yyx_q_distr(0.5, dnorm, c(-100,100))
#' qnorm(0.5)
#' # 0
#'
#' yyx_q_distr(0.975, dnorm, c(-100,100))
#' qnorm(0.975)
#' # 1.959964
#'
yyx_q_distr <- function(p, f, integrate_interval, uniroot_interval = integrate_interval, integrate_par=list(rel.tol=.Machine$double.eps^0.5), uniroot_par=list(tol=.Machine$double.eps^0.5)){
	integrate_interval <- range(integrate_interval)
	uniroot_interval <- range(uniroot_interval)
	
	integrate <- do.call(pryr::partial, c(integrate, integrate_par))
	uniroot <- do.call(pryr::partial, c(uniroot, uniroot_par))
	
	normalization_factor <- yyx_calculate_normalization_factor(f, integrate_interval, input_log_fun = FALSE, integrate_par = integrate_par)
	
	tmp <- unlist(lapply(p, function(this_p){
		uniroot(function(x){ integrate(f, min(integrate_interval), x)$value - normalization_factor * this_p }, uniroot_interval )$root
	}))
	stopifnot(length(tmp) == length(p))
	tmp
}

#' Numerical(empirical) density function value(s)
#'
#' \code{yyx_d_distr} numerically computes the density function values
#' on a given (unnormalized) distribution function
#'
#' The density function value was computed by
#' \enumerate{
#'   \item normalizing (calling \code{yyx_calculate_normalization_factor})
#'   \item compute the density function value just by calling \code{f}
#'           and divide the normalization factor
#' }
#'
#' @param x A numeric value (or vector), the quantiles.
#' @param f An R function, (unnormalized) distribution density function
#' @param integrate_interval A numeric vector, the specified numeric integration interval of x
#' @param integrate_par A list, any paramters passed to function \code{integrate}
#' @return A numeric value (or vector), the density function value(s)
#'
#' @seealso \code{\link{yyx_p_distr}}, \code{\link{yyx_q_distr}}
#' @seealso \code{\link{yyx_get_credible_interval}}, \code{\link{yyx_calculate_normalization_factor}}, \code{\link{yyx_normalize_distribution_function}}
#' @family distribution related functions
#'
#' @examples
#' yyx_d_distr(0, dnorm, c(-100,100))
#' yyx_d_distr(0, function(x) dnorm(x)*2, c(-100,100))
#' dnorm(0)
#' # 0.3989423
#'
#' yyx_d_distr(1, dnorm, c(-100,100))
#' yyx_d_distr(1, function(x) dnorm(x)*2, c(-100,100))
#' dnorm(1)
#' # 0.2419707
#'
yyx_d_distr <- function(x, f, integrate_interval, integrate_par=list(rel.tol=.Machine$double.eps^0.5)){
	integrate_interval <- range(integrate_interval)
	
	integrate <- do.call(pryr::partial, c(integrate, integrate_par))
	
	normalization_factor <- yyx_calculate_normalization_factor(f, integrate_interval, input_log_fun = FALSE, integrate_par = integrate_par)
	
	tmp <- unlist(lapply(x, function(this_x){
		f(this_x) / normalization_factor
	}))
	stopifnot(length(tmp) == length(x))
	tmp
}


#' Generate spline fitted function for the minus random variable
#'
#' \code{yyx_two_distribution_minus} numerically computes and generates spline fitted function for the minus random variable (difference of two independent random variable)
#'
#' The distribution of the difference variable was computed by numerically computing
#' the cross-correlation function of the two distribution function 
#' in a straight-forward "brute-force" manner
#'
#' @param funA An R function, (unnormalized) distribution density function of random variable A
#' @param funB An R function, (unnormalized) distribution density function of random variable B
#' @param inputA_interval A numeric vector, the specified valid definitional domain of random variable A
#' @param inputB_interval A numeric vector, the specified valid definitional domain of random variable B
#' @param out_interval A numeric vector, the specified valid definitional domain of output random variable A - B
#' @param knots An integer. How many theta sample points should be computed?
#' @param x_vec An integer, specifies the output x sample points.
#'  When \code{x_vec} is specified, \code{knots} is ignored
#' @param integrate_par A list, any paramters passed to function \code{integrate}
#' @param splinefun_par A list, any paramters passed to function \code{splinefun}
#' @return An R function (result of splinefun) of A - B, restricted to \code{out_interval}
#'
#' @seealso \code{\link{yyx_get_credible_interval}}, \code{\link{yyx_calculate_normalization_factor}}
#' @family distribution related functions
#'
#' @examples
#' tmp_funA <- function(x) dnorm(x, mean=1, sd=1)
#' tmp_funB <- function(x) dnorm(x, mean=0, sd=1.5)
#' curve(tmp_funA, -10, 10)
#' curve(tmp_funB, -10, 10, add=T, col='blue')
#' curve(yyx_two_distribution_minus(tmp_funA, tmp_funB, c(-100,100), c(-100,100), c(-100,100))(x), -10, 10, add=T, col='red', lty=2, lwd=2)
#' curve(dnorm(x, mean=1, sd=sqrt(1^2+1.5^2)), -10, 10, add=T, col='yellow2', lty=3, lwd=2)
#' # black solid : dnorm(mean=1, sd=1),  blue solid : dnorm(mean=0, sd=1.5)
#' # red & yellow dashed : yyx_two_distribution_minus(tmp_funA, tmp_funB, c(-100,100), c(-100,100), c(-100,100)) = dnorm(mean=1, sd=sqrt(1^2+1.5^2))
yyx_two_distribution_minus <- function(funA, funB, inputA_interval=c(0,1), inputB_interval=c(0,1), out_interval=c(-1,1), knots=2001, x_vec = seq(min(out_interval), max(out_interval), length.out=knots), integrate_par=list(rel.tol=.Machine$double.eps^0.5), splinefun_par=list()){
	inputA_interval <- range(inputA_interval)
	inputB_interval <- range(inputB_interval)
	
	integrate <- do.call(pryr::partial, c(integrate, integrate_par))
	splinefun <- do.call(pryr::partial, c(splinefun, splinefun_par))
	
	tmp_fun_for_one_x <- function(x){
#		integrate(
#			function(t){
#				funA(t+x)*funB(t)
#			}, min(integrate_interval), max(integrate_interval))$value
		# valid t_interval: [A1-x,A2-x] AND [B1,B2]
		t_interval_min <- max(inputB_interval[1], inputA_interval[1]-x)
		t_interval_max <- min(inputB_interval[2], inputA_interval[2]-x)
		if(t_interval_min < t_interval_max){
			integrate(
				function(t){
					funA(t+x)*funB(t)
				}, t_interval_min, t_interval_max)$value
		}else{
			0
		}
	}
	
#	x_vec <- seq(min(out_interval), max(out_interval), length.out=knots)
	y_vec <- unlist(lapply(x_vec, tmp_fun_for_one_x))
	stopifnot(length(x_vec)==length(y_vec))
	yyx_restrict_x_interval_function(splinefun(x_vec, y_vec), out_interval, 0)
}



### baseQ string parse functions

## reference: http://www.r-bloggers.com/ascii-code-table-in-r/
#' Get ASCII code of a char
#'
#' \code{char_to_ascii} converts one char to its ASCII code (integer)
#'
#' @section Reference:
#' \url{http://www.r-bloggers.com/ascii-code-table-in-r/}
#'
#' @param ch A one-char character string
#' @return An integer, the ASCII code of the input \code{ch}
#'
#' @seealso \code{\link{yyx_baseQ_string_to_phred_vec}}
#' @family baseQ string parse functions
#'
#' @examples
#' char_to_ascii("A")
#' # 65   # = 64 + 1
#'
#' char_to_ascii("a")
#' # 97   # = 96 + 1
#'
char_to_ascii <- function(ch){
	strtoi(charToRaw(ch),16L)
}

#' Convert phred baseQ string to the phred baseQ vector
#'
#' \code{yyx_baseQ_string_to_phred_vec} converts phred baseQ string to the phred baseQ (integer) vector, by calling function \code{char_to_ascii}
#'
#' @param str A character string, the phred baseQ string (coded in +33 or +64)
#' @param phred_shift An integer, the specified coding shift (+33 or +64)
#' @return A numeric vector containing integers, the phred baseQ vector
#'
#' @seealso \code{\link{char_to_ascii}}
#' @family baseQ string parse functions
#'
#' @examples
#' yyx_baseQ_string_to_phred_vec("ABBCCDBA")
#' # 32 33 33 34 34 35 33 32
#'
yyx_baseQ_string_to_phred_vec <- function(str, phred_shift = 33){
	if(length(str)>1)  warning("input \"str\" has length > 1, only the first item will be converted")
	if(!is.character(str[1]))  stop("input \"str\" seems not to be a character string")
	tmp <- unlist(lapply(strsplit(str[1], "")[[1]], char_to_ascii))
	stopifnot(length(tmp)==nchar(str))
	tmp - phred_shift
}



### mosaic posterior (numeric) functions

#' Compute the posterior probabilities of 4 genotypes
#'
#' \code{yyx_ref_het_alt_mosaic_posterior} computes the posterior probabilities of 4 genotypes 
#' (ref-hom, het, alt-hom, mosaic)  (not in log-space)
#'
#' @param likelihood_fun An R function, the likelihood function of theoretical allele fraction theta
#' @param ref_het_alt_mosaic_prior A length=4 numeric vector, specifies the prior of 4 genotypes
#'  (default = c(1,1,1,1), ie. posterior = "normalized" likelihood)
#' @param het_beta_prior_param A length=2 numeric vector, specifies parameters for the het beta distribution
#'  (recently only useful in exome sequencing)
#' @param output_log10_fun A bool value. Should output function be in log10-spece?
#' @param integrate_par A list, any paramters passed to function \code{integrate}
#' @return A length=4 numeric vector, the posterior probabilities of 4 genotypes
#'
#' @seealso \code{\link{yyx_wrapped_mosaic_hunter_for_one_site}}, \code{\link{yyx_likelihood_theta_splinefun__call_c}}, \code{\link{yyx_calculate_normalization_factor}}
#' @family mosaic posterior functions
#'
#' @examples
#' tmp_fun <- yyx_likelihood_theta_splinefun__call_c(rep(20, 60), rep(20, 40))
#' yyx_ref_het_alt_mosaic_posterior(tmp_fun)
#' # 3.590668e-51 5.176832e-01 4.390069e-91 4.823168e-01
#'
#' yyx_ref_het_alt_mosaic_posterior(tmp_fun, output_log10 = TRUE)
#' # -50.4448247  -0.2859360 -90.3575286  -0.3166676
#'
#' yyx_ref_het_alt_mosaic_posterior(tmp_fun, het_beta_prior_param = c(25,30))
#' # 1.524626e-51 7.952045e-01 1.864058e-91 2.047955e-01
#'
#' yyx_ref_het_alt_mosaic_posterior(tmp_fun, ref_het_alt_mosaic_prior = c(1,2e-4,1e-8,1e-7))
#' # 3.466402e-47 9.995344e-01 4.238138e-95 4.656248e-04
#'
#' yyx_ref_het_alt_mosaic_posterior(tmp_fun, ref_het_alt_mosaic_prior = c(1,2e-4,1e-8,1e-7), het_beta_prior_param = c(25,30))
#' # 9.585144e-48 9.998712e-01 1.171911e-95 1.287525e-04
#'
yyx_ref_het_alt_mosaic_posterior <- function(likelihood_fun, ref_het_alt_mosaic_prior = c(1,1,1,1), het_beta_prior_param = NULL, output_log10 = FALSE, integrate_par = list(rel.tol=.Machine$double.eps^0.5)){
	if(length(ref_het_alt_mosaic_prior)!=4){
		stop("input \"ref_het_alt_mosaic_prior\" should have length=4, prior probability (not log10) for ref-hom, het, alt-hom, mosaic")
	}
	
	mosaic_likelihood <- yyx_calculate_normalization_factor(likelihood_fun, c(0,1), integrate_par = integrate_par)
	ref_hom_log10likelihood <- yyx_log_function(likelihood_fun)(0) / log(10)
	alt_hom_log10likelihood <- yyx_log_function(likelihood_fun)(1) / log(10)
	het_log10likelihood <- yyx_log_function(likelihood_fun)(0.5) / log(10)
	
	mosaic_log10likelihood <- log(mosaic_likelihood) / log(10)
	ref_hom_likelihood <- 10 ^ ref_hom_log10likelihood
	alt_hom_likelihood <- 10 ^ alt_hom_log10likelihood
	het_likelihood <- 10 ^ het_log10likelihood
	
	if(!is.null(het_beta_prior_param)){
		if(length(het_beta_prior_param) == 2){
			tmp_beta_distr <- function(x) dbeta(x, shape1 = het_beta_prior_param[1], shape2 = het_beta_prior_param[2])
			het_distr <- yyx_multiply_two_functions(likelihood_fun, tmp_beta_distr)
			het_likelihood <- yyx_calculate_normalization_factor(het_distr, c(0,1), integrate_par = integrate_par)
			het_log10likelihood <- log(het_likelihood) / log(10)
		}else{
			stop("input het_beta_prior_param should be a length=2 vector, containing alpha and beta parameters for the beta distribution.")
		}
	}
	
	if(output_log10){
		tmp_vec <- c(ref_hom_log10likelihood, het_log10likelihood, alt_hom_log10likelihood, mosaic_log10likelihood)
		tmp_vec <- tmp_vec + log10(ref_het_alt_mosaic_prior)
		return( tmp_vec - yyx_log10_sum_exp10(tmp_vec) )
	}else{
		tmp_vec <- c(ref_hom_likelihood, het_likelihood, alt_hom_likelihood, mosaic_likelihood)
		tmp_vec <- tmp_vec * ref_het_alt_mosaic_prior
		return( tmp_vec / sum(tmp_vec) )
	}
}

#' Compute the likelihood function and posterior probabilities for one site
#'
#' \code{yyx_wrapped_mosaic_hunter_for_one_site} wraps function \code{yyx_baseQ_string_to_phred_vec}, 
#' \code{yyx_likelihood_theta_splinefun__call_c}, and \code{yyx_ref_het_alt_mosaic_posterior},
#' as a pipeline function for one NGS site
#'
#' @param ref_baseQ_str The ref baseQ phred string (when input_type = "string") or integer vector (when input_type = "integer_vector") 
#' @param alt_baseQ_str The alt baseQ phred string (when input_type = "string") or integer vector (when input_type = "integer_vector") 
#' @param input_type A character string specifying the input type of \code{ref_baseQ_str} and \code{alt_baseQ_str},
#'  must be one of "string" (default) or "integer_vector".
#' @param phred_shift An integer, the specified coding shift (+33 or +64)
#' @param knots An integer. How many theta sample points should be computed?
#' @param theta_vec A numeric vector, specifies the theta sample points.
#'  When \code{theta_vec} is specified, \code{knots} is ignored.
#'  (default see \code{\link{yyx_loglikelihood_theta_splinefun}})
#' @param ref_het_alt_mosaic_prior A length=4 numeric vector, specifies the prior of 4 genotypes
#'  (default = c(1,1,1,1), ie. posterior = "normalized" likelihood)
#' @param het_beta_prior_param A length=2 numeric vector, specifies parameters for the het beta distribution
#'  (recently only useful in exome sequencing)
#' @param output_log10_fun A bool value. Should output function be in log10-spece?
#' @param integrate_par A list, any paramters passed to function \code{integrate}
#' @param splinefun_par A list, any paramters passed to function \code{splinefun}
#' @return A list, contains \code{ref_het_alt_mosaic_posterior} and \code{likelihood_fun}.
#' \describe{
#'   \item{\code{ref_het_alt_mosaic_posterior}}{ is a length=4 numeric vector, the posterior probabilities of 4 genotypes }
#'   \item{\code{likelihood_fun}}{ is the R function of the spline fitted likelihood function of theta }
#' }
#'
#' @seealso \code{\link{yyx_wrapped_mosaic_hunter_for_one_site}}, \code{yyx_likelihood_theta_splinefun__call_c}, \code{\link{yyx_calculate_normalization_factor}}
#' @family mosaic posterior functions
#'
#' @examples
#' yyx_wrapped_mosaic_hunter_for_one_site("AAAAAAAAAA", "DDDDDDDD")
#' # $ref_het_alt_mosaic_posterior  1.980340e-23 7.602227e-01 1.987842e-27 2.397773e-01
#'
#' yyx_wrapped_mosaic_hunter_for_one_site(rep(20, 60), rep(20, 40), input_type = "integer_vector")
#' # $ref_het_alt_mosaic_posterior  3.590668e-51 5.176832e-01 4.390069e-91 4.823168e-01
#'
#' yyx_wrapped_mosaic_hunter_for_one_site(rep(20, 60), rep(20, 40), input_type = "integer_vector", het_beta_prior_param=c(25,30))
#' # 1.524626e-51 7.952045e-01 1.864058e-91 2.047955e-01
#'
#' yyx_wrapped_mosaic_hunter_for_one_site(rep(20, 60), rep(20, 40), input_type = "integer_vector", ref_het_alt_mosaic_prior=c(1,0,1e-4,1e-7), output_log10 = T)
#' # -43.12816      -Inf -87.04086   0.00000
#'
yyx_wrapped_mosaic_hunter_for_one_site <- function(ref_baseQ_str, alt_baseQ_str, input_type = "string", phred_shift = 33, knots = 1000, theta_vec = NULL, ref_het_alt_mosaic_prior = c(1,1,1,1), het_beta_prior_param = NULL, output_log10 = FALSE, integrate_par = list(rel.tol=.Machine$double.eps^0.5), splinefun_par = list()){
	ref_baseQ_vec <- ref_baseQ_str
	alt_baseQ_vec <- alt_baseQ_str
	if(input_type == "string"){
		ref_baseQ_vec <- yyx_baseQ_string_to_phred_vec(ref_baseQ_str, phred_shift = phred_shift)
		alt_baseQ_vec <- yyx_baseQ_string_to_phred_vec(alt_baseQ_str, phred_shift = phred_shift)
	}else if(input_type == "integer_vector"){
		# good, do nothing
	}else{
		stop("Unknown input_type, which should be \"string\" or \"integer_vector\"")
	}
	
	likelihood_fun <- yyx_likelihood_theta_splinefun__call_c(ref_baseQ_vec, alt_baseQ_vec, knots = knots, theta_vec = theta_vec, splinefun_par = splinefun_par)
	ref_het_alt_mosaic_posterior <- yyx_ref_het_alt_mosaic_posterior(likelihood_fun, ref_het_alt_mosaic_prior=ref_het_alt_mosaic_prior, het_beta_prior_param = het_beta_prior_param, output_log10 = output_log10, integrate_par = integrate_par)
	list(ref_het_alt_mosaic_posterior = ref_het_alt_mosaic_posterior, likelihood_fun = likelihood_fun)
}

