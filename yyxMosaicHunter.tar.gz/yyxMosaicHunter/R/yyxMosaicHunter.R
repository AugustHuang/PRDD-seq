#' Numerically compute the AF posterior distribution.
#'
#' \pkg{yyxMosaicHunter} allows you to numerically compute 
#' the posterior distribution of theoretical allele fraction theta for one site.
#'
#' \pkg{yyxMosaicHunter} also provides some utility functions
#' for numerically compute the integral area, posterior mean, credible interval
#' for any distribution density functions.
#'
#' @docType package
#' @name yyxMosaicHunter-package
#'
#' @section List of exported functions:
#' \subsection{general functions}{
#'   \code{\link{yyx_is_within_range}}
#'   \code{yyx_is_within_range__c}
#'   \code{\link{yyx_NA2FALSE}}
#'   \code{\link{yyx_convert_NA}}
#'   \code{\link{yyx_convert_NA_vec}}
#' }
#' \subsection{math functions}{
#'   \code{\link{yyx_log_sum_exp}}
#'   \code{yyx_log_add_exp__c}
#'   \code{yyx_log_sum_exp__c}
#'   \code{\link{yyx_log10_sum_exp10}}
#' }
#' \subsection{mosaic model related functions}{
#'   \code{\link{yyx_log_P_o_given_r_q}}
#'   \code{yyx_log_P_o_given_r_q__c}
#'   \code{\link{yyx_log_P_r_given_theta_depth}}
#'   \code{yyx_log_P_r_given_theta_depth__c}
#'   \code{\link{yyx_log_P_o_given_theta_q}}
#'   \code{yyx_log_P_o_given_theta_q__c}
#' }
#' \subsection{mosaic model spline-fit functions}{
#'   \code{\link{yyx_loglikelihood_theta_vec}}
#'   \code{\link{yyx_loglikelihood_theta_splinefun}}
#'   \code{\link{yyx_likelihood_theta_splinefun}}
#'   \code{yyx_loglikelihood_theta_vec__c}
#'   \code{\link{yyx_loglikelihood_theta_splinefun__call_c}}
#'   \code{\link{yyx_likelihood_theta_splinefun__call_c}}
#' }
#' \subsection{function parser functions}{
#'   \code{\link{yyx_keep_positive_function}}
#'   \code{\link{yyx_exp_function}}
#'   \code{\link{yyx_log_function}}
#'   \code{\link{yyx_restrict_x_interval_function}}
#'   \code{\link{yyx_restrict_y_interval_function}}
#'   \code{\link{yyx_multiply_two_functions}}
#' }
#' \subsection{distribution related functions}{
#'   \code{\link{yyx_calculate_normalization_factor}}
#'   \code{\link{yyx_normalize_distribution_function}}
#'   \code{\link{yyx_posterior_mean}}
#'   \code{\link{yyx_get_credible_interval}}
#'   \code{\link{yyx_get_posterior_p_value}}
#'   \code{\link{yyx_d_distr}}
#'   \code{\link{yyx_p_distr}}
#'   \code{\link{yyx_q_distr}}
#'   \code{\link{yyx_two_distribution_minus}}
#' }
#' \subsection{baseQ string parse functions}{
#'   \code{\link{char_to_ascii}}
#'   \code{\link{yyx_baseQ_string_to_phred_vec}}
#' }
#' \subsection{mosaic posterior functions}{
#'   \code{\link{yyx_ref_het_alt_mosaic_posterior}}
#'   \code{\link{yyx_wrapped_mosaic_hunter_for_one_site}}
#' }
#'
#' @examples
#' test_result <- yyx_wrapped_mosaic_hunter_for_one_site("AAAABBBBCCCCDDDD", "AABBCBDBC")
#' test_result$ref_het_alt_mosaic_posterior
#' # 2.568687e-23 6.125898e-01 5.140642e-47 3.874102e-01
#'
#' # draw likelihood curve
#' curve(test_result$likelihood_fun(x), 0, 1, n=1001L)
#'
#' yyx_get_credible_interval(test_result$likelihood_fun, c(0,1), 0.95)
#' # $CI  0.1959352 0.5497465
#' yyx_get_posterior_p_value(0.2, test_result$likelihood_fun, c(0,1))
#' # 0.05699002
#' 
#' 
#' yyx_wrapped_mosaic_hunter_for_one_site(rep(30, 20), rep(30, 10), input_type="integer_vector")$ref_het_alt_mosaic_posterior
#' # 4.883530e-22 4.640066e-01 4.932635e-52 5.359934e-01
#' 
#' yyx_wrapped_mosaic_hunter_for_one_site("AAAABBBBCCCCDDDD", "AABBCBDBC", output_log10=T)$ref_het_alt_mosaic_posterior
#' # -22.5902888  -0.2128303 -46.2889827  -0.4118289
#' 
#' yyx_wrapped_mosaic_hunter_for_one_site("AAAABBBBCCCCDDDD", "AABBCBDBC", ref_het_alt_mosaic_prior=c(1,2e-4,1e-8,1e-7))$ref_het_alt_mosaic_posterior
#' # 2.095917e-19 9.996839e-01 4.194501e-51 3.161070e-04
#' 
#' yyx_wrapped_mosaic_hunter_for_one_site("AAAABBBBCCCCDDDD", "AABBCBDBC", ref_het_alt_mosaic_prior=c(1,2e-4,1e-8,1e-7), output_log10=T)$ref_het_alt_mosaic_posterior
#' # -1.867863e+01 -1.373052e-04 -5.037732e+01 -3.500166e+00
#' 
#' yyx_wrapped_mosaic_hunter_for_one_site("AAAABBBBCCCCDDDD", "AABBCBDBC", het_beta_prior_param=c(30,40))$ref_het_alt_mosaic_posterior
#' # 1.627434e-23 7.545498e-01 3.256939e-47 2.454502e-01
#' 
#' yyx_wrapped_mosaic_hunter_for_one_site("AAAABBBBCCCCDDDD", "AABBCBDBC", ref_het_alt_mosaic_prior=c(1,2e-4,1e-8,1e-7), het_beta_prior_param=c(30,40))$ref_het_alt_mosaic_posterior
#' # 1.078239e-19 9.998374e-01 2.157849e-51 1.626203e-04
#' 
#' yyx_wrapped_mosaic_hunter_for_one_site("AAAABBBBCCCCDDDD", "AABBCBDBC", ref_het_alt_mosaic_prior=c(1,0,1e-4,1e-7))$ref_het_alt_mosaic_posterior
#' # 6.630405e-16 0.000000e+00 1.326925e-43 1.000000e+00
#' 
NULL
